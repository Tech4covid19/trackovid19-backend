'use strict'

module.exports = async (fastify, opts) => {
  /* TODO */
}