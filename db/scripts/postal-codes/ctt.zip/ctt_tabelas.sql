create table public.ctt_distrito
(
	cod_distrito character(2), -- Código do distrito
	nome_distrito character varying(100) --  Nome do distrito
);

create table public.ctt_concelho
(
	cod_distrito character(2), -- Código do distrito
	cod_concelho character(2), -- Código do concelho
	nome_concelho character varying(100) -- Nome do concelho
);

create table public.ctt_codigo_postal
(
	cod_distrito character(2), -- Código do distrito
	cod_concelho character(2), -- Código do concelho
	cod_localidade character varying(10), -- Código da localidade
	nome_localidade character varying(200), -- Nome da localidade
	cod_arteria character varying(200), -- Código da artéria
	tipo_arteria character varying(200), -- Tipo de artéria (Rua, Praça, etc)
	prep1 character varying(200), -- Primeira preposição
	titulo_arteria character varying(200), -- Título (Doutor, Eng.º, Professor, etc)
	prep2 character varying(200), -- Segunda preposição
	nome_arteria character varying(200), -- Designação da artéria
	local_arteria character varying(200), -- Local da artéria
	troco character varying(200), -- Descrição do troço
	porta character varying(200), -- Número da porta do cliente
	cliente character varying(200), -- Nome do cliente
	num_cod_postal character varying(200), -- Número do código postal
	ext_cod_postal character varying(200), -- Extensão do número do código postal
	desig_postal character varying(200) -- Designação postal
);
