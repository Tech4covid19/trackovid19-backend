
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('01', 'Aveiro');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('02', 'Beja');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('03', 'Braga');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('04', 'Bragança');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('05', 'Castelo Branco');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('06', 'Coimbra');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('07', 'Évora');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('08', 'Faro');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('09', 'Guarda');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('10', 'Leiria');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('11', 'Lisboa');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('12', 'Portalegre');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('13', 'Porto');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('14', 'Santarém');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('15', 'Setúbal');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('16', 'Viana do Castelo');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('17', 'Vila Real');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('18', 'Viseu');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('31', 'Ilha da Madeira');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('32', 'Ilha de Porto Santo');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('41', 'Ilha de Santa Maria');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('42', 'Ilha de São Miguel');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('43', 'Ilha Terceira');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('44', 'Ilha da Graciosa');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('45', 'Ilha de São Jorge');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('46', 'Ilha do Pico');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('47', 'Ilha do Faial');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('48', 'Ilha das Flores');
INSERT INTO public.ctt_distrito (cod_distrito, nome_distrito) VALUES ('49', 'Ilha do Corvo');


-- Completed on 2020-03-28 22:59:23 WET

--
-- PostgreSQL database dump complete
--

